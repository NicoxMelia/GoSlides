# GoSlides AI Capability Pack v0.15.0

Este ZIP es el contrato de autoría para una IA. Describe qué puede renderizar GoSlides, cómo elegir cada componente y cómo producir un ZIP importable. No es una presentación ni contiene material del usuario.

## Orden de lectura recomendado

1. `manifest.json` — versión e inventario del paquete.
2. `authoring-guide.md` — estrategia narrativa y de densidad.
3. `catalog/components.json` — cuándo usar cada bloque.
4. `catalog/themes.json` y `catalog/design-system.json` — sistema visual disponible.
5. `schema/*.json` — contrato estructural de salida.
6. `examples/complete-demo/` — ejemplos reales y combinaciones.
7. `brief-template.md` — información que debe aportar el usuario.

## Contrato de salida

La IA debe entregar un ZIP GoSlides v2 con `presentation.json`, archivos `slides/*.json` y assets referenciados bajo `assets/`. Antes de entregar, debe ejecutar `npm run audit`, `npm run regression` y revisar visualmente el Viewer.
