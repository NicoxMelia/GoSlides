# Brief de presentación

## Objetivo

## Audiencia

## Mensaje principal

## Duración y cantidad aproximada de slides

## Contenido obligatorio

## Fuentes de verdad y prioridad

## Densidad
visual | balanced | detailed | documentary

## Profundidad
summary | class | workshop | reference

## Interacción
none | occasional | frequent

## Estrategia de overflow
split | reveal | appendix | preserve

## Estilo o tema preferido
Dejar vacío para que la IA elija desde catalog/themes.json.

## Restricciones
